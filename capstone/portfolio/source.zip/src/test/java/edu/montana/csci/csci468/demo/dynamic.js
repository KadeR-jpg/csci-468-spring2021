
var x = 10
x = "foo"
console.log(x.length);
x = [1, 2, 3];
console.log(x.length);